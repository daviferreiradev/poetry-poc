"""poetry_poc package for Poetry POC."""

__version__ = "0.1.0"

